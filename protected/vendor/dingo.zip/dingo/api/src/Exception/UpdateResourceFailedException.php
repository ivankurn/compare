<?php

namespace Dingo\Api\Exception;

class UpdateResourceFailedException extends ResourceException
{
    //
}
