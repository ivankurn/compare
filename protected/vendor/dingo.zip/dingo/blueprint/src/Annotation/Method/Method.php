<?php

namespace Dingo\Blueprint\Annotation\Method;

abstract class Method
{
    /**
     * @var string
     */
    public $uri;
}
