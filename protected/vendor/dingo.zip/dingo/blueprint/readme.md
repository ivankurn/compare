# API Blueprint Generator

[![Build Status](https://img.shields.io/travis/dingo/blueprint/master.svg?style=flat-square)](https://travis-ci.org/dingo/blueprint)
[![License](https://img.shields.io/packagist/l/dingo/blueprint.svg?style=flat-square)](https://packagist.org/packages/dingo/blueprint)
![Development Version](https://img.shields.io/packagist/vpre/dingo/blueprint.svg?style=flat-square)
![Monthly Installs](https://img.shields.io/packagist/dm/dingo/blueprint.svg?style=flat-square)
[![StyleCI](https://styleci.io/repos/37761089/shield)](https://styleci.io/repos/37761089)

This package generates a valid API Blueprint 1A document from a collection of classes.

## Usage

More information coming soon.

## License

This package is licensed under the [BSD 3-Clause license](http://opensource.org/licenses/BSD-3-Clause).
