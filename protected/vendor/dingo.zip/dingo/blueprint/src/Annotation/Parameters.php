<?php

namespace Dingo\Blueprint\Annotation;

/**
 * @Annotation
 */
class Parameters
{
    /**
     * @array<Parameter>
     */
    public $value;
}
