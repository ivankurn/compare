<?php

namespace Dingo\Api\Event;

class ResponseWasMorphed extends ResponseIsMorphing
{
    //
}
