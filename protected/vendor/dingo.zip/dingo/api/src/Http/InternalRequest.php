<?php

namespace Dingo\Api\Http;

class InternalRequest extends Request
{
    //
}
